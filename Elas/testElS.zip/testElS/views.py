from django.shortcuts import render, redirect
from django.utils import timezone

import requests
import json

def index(request):
    return render(request, 'index.html')


def elaSearch(request):
    if request.method == 'GET':
        q = request.GET['q']

        query = f'http://localhost:9200/_search?q={q}&size=30'
        ela_data = requests.get(query)
        search_data = json.loads(ela_data.text)
        hits_datas = search_data['hits']['hits']

        result = list()
        for data in hits_datas:
            hits_data = {'id': data['_id'], 'source': data['_source']}
            result.append(hits_data)


        return render(request, 'search.html', {'result': result})