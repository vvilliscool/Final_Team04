from django.shortcuts import render, redirect
from django.utils import timezone
from elasticsearch import Elasticsearch
from django.http import JsonResponse

import requests
import json

def index(request):
    return render(request, 'index.html')


def elaSearch(request):
    if request.method == 'GET':
        q = request.GET['q']
        # query = f'http://localhost:9200/test/_search?q={q}&size=30'
        # ela_data = requests.get(query)
        es = Elasticsearch("http://localhost:9200")
        index = 'inch'
        body = {
            "query" : {
                "multi_match" : {
                    "fields" : ["s_name", "s_road", "s_add", "s_kind"],
                    "query" : q,
                    "type" : "phrase_prefix"
                }
            }
        }
        res = es.search(index=index, body=body)
        hits_datas = res['hits']['hits']

        result = list()
        for data in hits_datas:
            hits_data = {'id': data['_id'], 'source': data['_source']}
            result.append(hits_data)


        return render(request, 'search.html', {'result': result})

def autocom(request):
    es = Elasticsearch("http://localhost:9200")
    index = 'inch'

    q = request.GET.get("key")
    if q == None:
        result = {"key": None}
        return result

    body = {
        "query" : {
            "multi_match" : {
                "fields" : ["s_name"],
                "query" : q,
                "type" : "phrase_prefix"
            }
        }
    }
    res = es.search(index=index, body=body)
    hits_datas = res['hits']['hits']

    s_name = list()
    for data in hits_datas:
        hits_data = {'s_name': data['_source']['s_name']}
        s_name.append(hits_data)
    print(s_name)
    result = {"key": s_name}

    return JsonResponse(result)